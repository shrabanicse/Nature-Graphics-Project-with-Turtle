#import turtle
import turtle

def cloud_moving(sh):
    sh.fillcolor("white")
    sh.begin_fill()
    sh.circle(50)
    sh.forward(100)
    sh.left(90)
    sh.forward(20)
    sh.left(90)
    sh.circle(45)
    sh.forward(20)
    sh.right(90)
    sh.forward(20)
    sh.left(90)
    sh.forward(60)
    sh.left(90)
    sh.circle(45)
    sh.forward(20)
    sh.right(90)
    sh.circle(45)
    sh.forward(20)
    sh.left(90)
    sh.forward(20)
    sh.end_fill()
    sh.left(90)
    sh.forward(0.1)

t=turtle.Turtle()
t.speed(10)
scr=turtle.getscreen()
scr.title("Nature")
scr.bgcolor("SkyBlue")

#create the body of house
t.penup()
t.pensize(3)
t.color("brown","orange")
t.begin_fill()
t.goto(-80,-200)
t.pendown()
t.forward(350)
t.left(90)
t.forward(150)
t.left(90)
t.forward(350)
t.left(90)
t.forward(150)
t.left(90)
t.end_fill()

#create partiton
t.forward(100)
t.left(90)
t.forward(150)
t.left(90)
t.forward(100)
t.end_fill()

#create roof
t.color("brown","purple")
t.begin_fill()
t.right(120)
t.forward(100)
t.right(120)
t.forward(100)
t.end_fill()
t.begin_fill()
t.backward(100)
t.left(60)
t.forward(250)
t.right(60)
t.forward(100)
t.end_fill()
t.penup()

#create door
t.goto(-80,-200)
t.setheading(0)
t.pendown()
t.color("brown","aqua")
t.forward(230)
t.left(90)
t.begin_fill()
t.forward(90)
t.right(90)
t.forward(50)
t.right(90)
t.forward(90)
t.end_fill()
t.penup()

#grass
t.color("brown", "green")
t.goto(-800,-200)
t.left(90)
t.pendown()
t.begin_fill()
t.forward(1600)
t.right(90)
t.forward(200)
t.right(90)
t.forward(1600)
t.right(90)
t.forward(200)
t.end_fill()
t.penup()

#create clouds
t.penup()
t.goto(500,180)
t.pendown()
t.color("white","white")
t.setheading(90)
t.begin_fill()
t.circle(60,180)
t.end_fill()
t.penup()
t.goto(440,180)
t.setheading(90)
t.begin_fill()
t.circle(80,180)
t.end_fill()
t.penup()

t.goto(750,200)
t.pendown()
#t.color("white","white")
t.setheading(90)
t.begin_fill()
t.circle(60,180)
t.end_fill()
t.penup()
t.goto(690,200)
t.setheading(90)
t.begin_fill()
t.circle(80,180)
t.end_fill()
t.penup()

t.goto(-90,180)
t.pendown()
t.color("white","white")
t.setheading(90)
t.begin_fill()
t.circle(60,180)
t.end_fill()
t.penup()
t.goto(-120,180)
t.setheading(90)
t.begin_fill()
t.circle(80,180)
t.end_fill()
t.penup()

t.goto(-300,210)
t.pendown()
t.setheading(90)
t.begin_fill()
t.circle(60,180)
t.end_fill()
t.penup()
t.goto(-350,210)
t.setheading(90)
t.begin_fill()
t.circle(80,180)
t.end_fill()
t.penup()

#Tree1
t.color("SeaGreen")
t.pensize(20)
t.begin_fill()
t.goto(-200,-120)
t.pensize(1)
t.begin_fill()
t.setheading(0)

# Creating Right half of the tree
t.forward(100)
t.left(150)
t.forward(90)
t.right(150)
t.forward(60)
t.left(150)
t.forward(60)
t.right(150)
t.forward(40)
t.left(150)
t.forward(100)
t.end_fill()

# left half of the tree
t.begin_fill()
t.left(60)
t.forward(100)
t.left(150)
t.forward(40)
t.right(150)
t.forward(60)
t.left(150)
t.forward(60)
t.right(150)
t.forward(90)
t.left(150)
t.forward(133)
t.end_fill()
t.penup()

# Creating the trunck of the tree
t.color("brown")
t.pensize(1)
t.begin_fill()
t.right(90)
t.forward(80)
t.right(90)
t.forward(40)
t.right(90)
t.forward(80)
t.end_fill()
t.penup()

#Mountine
t.pensize(20)
t.begin_fill()
t.goto(-500,-120)
t.color("DarkSlateGray")
t.pensize(1)
t.begin_fill()
t.setheading(0)

# left half of the tree
t.begin_fill()
t.left(150)
t.forward(100)
t.left(100)
t.forward(40)
t.right(120)
t.forward(60)
t.left(100)
t.forward(60)
t.right(100)
t.forward(90)
t.left(100)
t.forward(133)
t.end_fill()
t.penup()

#Tree2
t.pensize(5)
t.begin_fill()
t.goto(670,-120)
t.color("green4")
t.pensize(1)
t.begin_fill()
t.setheading(0)

# Creating Right half of the tree
t.forward(100)
t.left(150)
t.forward(90)
t.right(150)
t.forward(60)
t.left(150)
t.forward(60)
t.right(150)
t.forward(40)
t.left(150)
t.forward(100)
t.end_fill()

# left half of the tree
t.begin_fill()
t.left(60)
t.forward(100)
t.left(150)
t.forward(40)
t.right(150)
t.forward(60)
t.left(150)
t.forward(60)
t.right(150)
t.forward(90)
t.left(150)
t.forward(133)
t.end_fill()
t.penup()

# Creating the trunck of the tree
t.color("brown")
t.pensize(1)
t.begin_fill()
t.right(90)
t.forward(80)
t.right(90)
t.forward(40)
t.right(90)
t.forward(80)
t.end_fill()
t.penup()

# Yellow flower
t.color("yellow")
t.penup()
t.speed(100)
t.pensize(3)
t.goto(-250,-210)
t.pendown()
t.begin_fill()
for _ in range(7):
    for _ in range(2):
        t.circle(20.0, 60.0)
        t.left(180 - 60.0)
    t.left(360.0 / 7)
t.end_fill()
t.penup()

#Red flower
t.goto(-300,-240)
t.color("red")
t.penup()
t.pensize(3)
t.pendown()
t.begin_fill()
for _ in range(7):
    for _ in range(2):
        t.circle(20.0, 60.0)
        t.left(180 - 60.0)
    t.left(360.0 / 7)
t.end_fill()
t.penup()

#Purple flower
t.goto(-280,-220)
t.color("purple")
t.penup()
t.pensize(3)
t.pendown()
t.begin_fill()
for _ in range(7):
    for _ in range(2):
        t.circle(20.0, 60.0)
        t.left(180 - 60.0)
    t.left(360.0 / 7)
t.end_fill()
t.penup()

#White flower
t.goto(-200,-210)
t.color("white")
t.penup()
t.pensize(3)
t.pendown()
t.begin_fill()
for _ in range(7):
    for _ in range(2):
        t.circle(20.0, 60.0)
        t.left(180 - 60.0)
    t.left(360.0 / 7)
t.end_fill()
t.penup()

#Blue flower
t.goto(-170,-230)
t.color("blue")
t.penup()
t.pensize(3)
t.pendown()
t.begin_fill()
for _ in range(7):
    for _ in range(2):
        t.circle(20.0, 60.0)
        t.left(180 - 60.0)
    t.left(360.0 / 7)
t.end_fill()
t.penup()

#Orange flower
t.goto(-150,-250)
t.color("orange")
t.penup()
t.pensize(3)
t.pendown()
t.begin_fill()
for _ in range(7):
    for _ in range(2):
        t.circle(20.0, 60.0)
        t.left(180 - 60.0)
    t.left(360.0 / 7)
t.end_fill()
t.penup()

#Pink flower
t.goto(-600,-250)
t.color("pink")
t.penup()
t.pensize(3)
t.pendown()
t.begin_fill()
for _ in range(7):
    for _ in range(2):
        t.circle(20.0, 60.0)
        t.left(180 - 60.0)
    t.left(360.0 / 7)
t.end_fill()
t.penup()

#Indigo flower
t.goto(-400,-320)
t.color("indigo")
t.penup()
t.pensize(3)
t.pendown()
t.begin_fill()
for _ in range(7):
    for _ in range(2):
        t.circle(20.0, 60.0)
        t.left(180 - 60.0)
    t.left(360.0 / 7)
t.end_fill()
t.penup()

#Lime flower
t.goto(-20,-330)
t.color("lime")
t.penup()
t.pensize(3)
t.pendown()
t.begin_fill()
for _ in range(7):
    for _ in range(2):
        t.circle(20.0, 60.0)
        t.left(180 - 60.0)
    t.left(360.0 / 7)
t.end_fill()
t.penup()

#Maroon flower
t.goto(140,-260)
t.color("maroon")
t.penup()
t.pensize(3)
t.pendown()
t.begin_fill()
for _ in range(7):
    for _ in range(2):
        t.circle(20.0, 60.0)
        t.left(180 - 60.0)
    t.left(360.0 / 7)
t.end_fill()
t.penup()

#Aqua flower
t.goto(340,-330)
t.color("aqua")
t.penup()
t.pensize(3)
t.pendown()
t.begin_fill()
for _ in range(7):
    for _ in range(2):
        t.circle(20.0, 60.0)
        t.left(180 - 60.0)
    t.left(360.0 / 7)
t.end_fill()
t.penup()

#Red flower
t.goto(-150,-550)
t.color("red")
t.penup()
t.pensize(3)
t.pendown()
t.begin_fill()
for _ in range(7):
    for _ in range(2):
        t.circle(20.0, 60.0)
        t.left(180 - 60.0)
    t.left(360.0 / 7)
t.end_fill()
t.penup()

#Gold flower
t.goto(570,-250)
t.color("gold")
t.penup()
t.pensize(3)
t.pendown()
t.begin_fill()
for _ in range(7):
    for _ in range(2):
        t.circle(20.0, 60.0)
        t.left(180 - 60.0)
    t.left(360.0 / 7)
t.end_fill()
t.penup()

# Creating turtle object
t.penup()
t.color("brown")
t.begin_fill()
t.speed(2)
t.goto(500,-200)
t.pendown()

# Draw the mountain
t.fillcolor("DarkSlateGray")
t.begin_fill()
t.right(-90)
t.forward(160)
t.right(120)
t.forward(160)
t.right(120)
t.forward(160)
t.right(120)
t.end_fill()
t.penup()

t.color("brown")
t.begin_fill()
t.speed(2)
t.goto(520,-50)
t.pendown()

# Draw the mountain
t.fillcolor("DarkSlateGray")
t.begin_fill()
t.left(60)
t.forward(180)
t.left(120)
t.forward(180)
t.left(120)
t.forward(180)
t.left(120)
t.end_fill()
t.penup()

def move_obj(t):
    t.fillcolor('yellow')
    t.begin_fill()
    t.circle(60)
    t.end_fill()

import turtle as t

# Function to move the flower
def move_flower():
    for _ in range(40):
        t.clear()

        # Calculate the new position of the flower
        x, y = t.position()
        x += 5

        # Navy blue flower
        t.penup()
        t.goto(x, -250)
        t.pendown()
        t.color("navyblue")
        t.pensize(3)
        t.begin_fill()
        for _ in range(7):
            for _ in range(2):
                t.circle(20.0, 60.0)
                t.left(180 - 60.0)
            t.left(360.0 / 7)
        t.end_fill()

        t.penup()
        t.update()
        t.forward(0)

screen = t.Screen()
screen.bgcolor("pink")
t.speed(0)
move_flower()

# Main Code
if __name__ == "__main__":
    scr = turtle.Screen()
    scr.setup(700, 700)
    scr.bgcolor('light green')
    scr.tracer(0)
    t = turtle.Turtle()
    t.color('red')
    t.width(2)
    t.hideturtle()
    t.penup()
    t.goto(-500, 250)
    t.pendown()
    sh=turtle.Turtle()
    sh.color('white')
    sh.speed(1)
    sh.penup()
    sh.goto(-600,180)
    sh.pendown()
    x=1
    for x in range(11000):
        sh.clear()
        cloud_moving(sh)
        scr.update()

    while True:
        t.clear()
        move_obj(t)
        scr.update()
        t.forward(0.5)

turtle.done()